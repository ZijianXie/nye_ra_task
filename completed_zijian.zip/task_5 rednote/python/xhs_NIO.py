import random
import time
from pprint import pprint
import requests
import execjs
import json
import csv

from requests import RequestException

base_headers = {
    "accept": "application/json, text/plain, */*",
    "accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
    "cache-control": "no-cache",
    "content-type": "application/json;charset=UTF-8",
    "dnt": "1",
    "origin": "https://www.xiaohongshu.com",
    "pragma": "no-cache",
    "priority": "u=1, i",
    "referer": "https://www.xiaohongshu.com/",
    "sec-ch-ua": '"Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "cookie": "acw_tc=0a00dadb17537717168611047e76bc45ab7911d5393a428d366e79311ae29c; abRequestId=7b94ecca-2e2d-5f38-a103-ad8f31c8f024; webBuild=4.74.3; xsecappid=xhs-pc-web; loadts=1753771718460; a1=19854f0b73cv1qseqoi4v8kmag4q4is3wrwxi9k1q30000313917; webId=874c4cd7399b05acb064f1924f8b0bf7; websectiga=29098a4cf41f76ee3f8db19051aaa60c0fc7c5e305572fec762da32d457d76ae; sec_poison_id=83040db0-fc5c-4a82-80b4-cf7eb9c5f763; gid=yjY24i8fKiEyyjY24i8DWFjTqShyAMdAl34hEyAYT60k4Cq8A43Mq3888qyqjyW8DS0488yS; web_session=040069799e7bfbc9446d9f26bd3a4b023cd164; unread={%22ub%22:%22688486f40000000010025710%22%2C%22ue%22:%2268886ce300000000050077e0%22%2C%22uc%22:28}",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
}


def post_request(url, uri, data, max_retries=5, delay=5):
    sign_header = xhs_sign_obj.call('sign', uri, data, base_headers.get('cookie', ''))
    headers = {**base_headers, **sign_header}
    data = json.dumps(data, separators=(',', ':'), ensure_ascii=False)

    retries = 0
    while retries < max_retries:
        try:
            response = requests.post(url, headers=headers, data=data.encode('utf-8'))
            return response
        except RequestException:
            print(f"\n请求发生错误, 正在重新请求...\n")
            retries += 1
            time.sleep(delay)
    print(f"\n重新请求失败，请尝试更换 cookie 或者 页面上刷新验证 或者 更换账号尝试\n")


# 时间戳转换成日期
def get_time(ctime):
    timeArray = time.localtime(int(ctime / 1000))
    otherStyleTime = time.strftime("%Y.%m.%d", timeArray)
    return str(otherStyleTime)


# 保存笔记数据
def sava_data(note_data, note_id, xsec_token, user_url, image_urls, video_url):
    data_dict = {
        "post_title": note_data['note_card']['title'].strip(),
        "post_url": "https://www.xiaohongshu.com/explore/" + note_id + f"?xsec_token={xsec_token}&xsec_source=pc_feed",
        "author_name": note_data['note_card']['user']['nickname'].strip(),
        "date_published": get_time(note_data['note_card']['time']),
        "comments": note_data['note_card']['interact_info']['comment_count'],
        "likes": note_data['note_card']['interact_info']['liked_count'],
        "caption": note_data['note_card']['desc'].replace('\n', '').strip(),
        "user_url": user_url,
        "video_url": video_url,
        "images_url": image_urls
    }
    print(data_dict)
    # 笔记数量+1
    global note_count
    note_count += 1
    if note_count <= 100:
        writer.writerow(data_dict)


def get_note_info(note_id, xsec_token, user_url, image_urls, video_url):
    note_url = 'https://edith.xiaohongshu.com/api/sns/web/v1/feed'

    data = {
        "source_note_id": note_id,
        "image_scenes": ["jpg", "webp", "avif"],
        "extra": {"need_body_topic": "1"},
        "xsec_token": xsec_token,
        "xsec_source": "pc_search"

    }

    response = post_request(note_url, uri='/api/sns/web/v1/feed', data=data)
    json_data = response.json()
    # pprint(json_data)

    try:
        note_data = json_data['data']['items'][0]
    except:
        print(f'笔记 {note_id} 不允许查看')
        return
    sava_data(note_data, note_id, xsec_token, user_url, image_urls, video_url)


def keyword_search(keyword):
    search_url = "https://edith.xiaohongshu.com/api/sns/web/v1/search/notes"
    page_count = 20  # 爬取的页数, 一页有 20 条笔记 最多只能爬取220条笔记
    for page in range(1, page_count):
        # 排序方式 general: 综合排序 popularity_descending: 热门排序 time_descending: 最新排序
        data = {
            "ext_flags": [],
            "image_formats": ["jpg", "webp", "avif"],
            "keyword": keyword,
            "note_type": 0,
            "page": page,
            "page_size": 20,
            'search_id': xhs_sign_obj.call('searchId'),
            "sort": "general"
        }

        response = post_request(search_url, uri='/api/sns/web/v1/search/notes', data=data)
        json_data = response.json()
        # pprint(json_data)

        try:
            notes = json_data['data']['items']
        except:
            print('================爬取完毕================'.format(page))
            break

        for note in notes:
            if note.get('note_card', ''):
                # 提取笔记ID
                note_id = note['id']
                # 提取作者昵称
                author_name = note['note_card']['user']['nickname']  # 作者昵称
                # 提取笔记标题
                post_title = note['note_card'].get('display_title', '')  # 帖子标题
                # 提取发布时间标签
                date_published = note['note_card']['corner_tag_info'][0]['text']  # 发布时间
                # 提取评论数
                comments = note['note_card']['interact_info']['comment_count']  # 评论数
                # 提取点赞数
                likes = note['note_card']['interact_info']['liked_count']  # 点赞数
                # 提取安全令牌
                xsec_token = note['xsec_token']
                # 构建笔记详情页URL
                post_url = f"https://www.xiaohongshu.com/explore/{id}?xsec_token={xsec_token}"  # 帖子链接
                time.sleep(2)

                # 视频URL字段（保留为空）
                video_url = ''

                # 提取图片列表
                images_urls = note['note_card']['image_list']
                images_urls_list = []
                # 处理每张图片的URL
                for images_url in images_urls:
                    images_url = images_url['info_list'][0].get('url', '')
                    images_urls_list.append(images_url)
                # 合并图片URL为字符串（用换行分隔）
                image_urls = '\n'.join(images_urls_list)

                # 提取用户ID
                user_id = note['note_card']['user']['user_id']
                # 提取用户安全令牌
                xsec_token_user = note['note_card']['user']['xsec_token']
                # 构建用户主页URL
                user_url = f"https://www.xiaohongshu.com/user/profile/{user_id}?xsec_token={xsec_token_user}"
                if len(note_id) != 24:
                    continue

                get_note_info(note_id, xsec_token, user_url, image_urls, video_url)


if __name__ == "__main__":
    note_count = 0
    xhs_sign_obj = execjs.compile(open('xhs.js', encoding='utf-8').read())

    keyword = 'NIO'  # 搜索的关键词

    # 向csv文件写入表头  笔记数据csv文件
    header = ['post_url', 'author_name', 'likes', 'comments', 'post_title',
              'caption', 'date_published', 'video_url',
              'user_url', 'images_url']

    f = open(f"{keyword}.csv", "w", encoding="utf-8-sig", newline="")
    writer = csv.DictWriter(f, header)
    writer.writeheader()
    keyword_search(keyword)
